#ifndef RRH
#define RRH

#include "lwp.h"

extern scheduler RoundRobin;
extern struct scheduler rr_publish; /* for static initialization */

#endif
